from navapol.studentclass import Student, SpecialStudent
